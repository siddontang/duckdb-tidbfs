"""Final pinned build, compatibility/fault suite, then sequential measurements."""
import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd(); out=root/'build/cpp-migration'; py=root/'build/quack-perf/venv/bin/python'
env=dict(os.environ, DUCKDB_AGENT_MODE='0', DUCKDB=str(root/'build/duckdb-2.0.0/bin/duckdb'),
 CMAKE=str(root/'build/object-venv/bin/cmake'), CTEST=str(root/'build/object-venv/bin/ctest'),
 OPENSSL_ROOT_DIR='/opt/homebrew/opt/openssl@3', CMAKE_ARGS='-DOPENSSL_ROOT_DIR=/opt/homebrew/opt/openssl@3',
 TIDBFS_QUACK_EXTENSION=str(root/'build/duckdb-2.0.0/extensions/v2.0.0/osx_arm64/quack.duckdb_extension'),
 TIDBFS_REQUIRE_SESSION_GUARD='1', TIDBFS_INTEROP_EXTENSION=str(out/'go-baseline/tidbfs.duckdb_extension'),
 PATH=str(py.parent)+os.pathsep+os.environ['PATH'], BUILD_JOBS='4')
env.pop('DRIVE9_CPP_SOURCE',None)
state={'stage':'starting','completed':[], 'sdk_revision':(root/'cpp-sdk-revision.txt').read_text().strip(), 'plugin_source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'fs_provenance':json.loads((out/'fs-build-provenance.json').read_text())}
def save(): (out/'final-pipeline.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,args):
 state['stage']=name;save();print('Starting',name,flush=True)
 with (out/(name+'.log')).open('w') as log: subprocess.run(args,env=env,stdout=log,stderr=log,check=True)
 state['completed'].append(name);save();print('Completed',name,flush=True)
try:
 run('final-build',[str(py),'scripts/build.py','--duckdb',env['DUCKDB'],'--include',str(root/'build/duckdb-2.0.0/archive/duckdb-2.0.0/src/include')])
 state['binary_sha256']=hashlib.sha256((root/'build/tidbfs.duckdb_extension').read_bytes()).hexdigest();save()
 run('final-analytical',[str(py),'-m','unittest','discover','-s','test','-v'])
 run('final-interop',[str(py),'scripts/test_native_live.py','--tidb-server','build/tidb-tikv-wrapper.py','--fs-server','build/fs-cpp-optin-server','--rustfs-server','build/rustfs','--skip-restart','--log-dir',str(out/'final-interop'),'NativeDatabaseTests.test_prior_client_file_format_interoperability'])
 run('final-live',[str(py),'scripts/test_native_live.py','--tidb-server','build/tidb-tikv-wrapper.py','--fs-server','build/fs-cpp-optin-server','--rustfs-server','build/rustfs','--quack','--log-dir',str(out/'final-live')])
 if (out/'hold-performance').exists():
  state['stage']='validated';save();raise SystemExit(0)
 assert state['sdk_revision']==(root/'cpp-sdk-revision.txt').read_text().strip(), 'SDK pin changed during validation'
 run('performance',[str(py),str(out/'run_benchmarks.py')])
 state['stage']='complete';save()
except Exception as err:
 state.update(stage='failed',error=type(err).__name__+': '+str(err));save();raise
