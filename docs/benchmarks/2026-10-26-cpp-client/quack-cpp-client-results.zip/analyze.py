"""Select complete resource-qualified groups and plot final benchmark results."""
import base64,csv,hashlib,html,json,statistics,sys,zipfile
from collections import defaultdict
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'build/cpp-migration'
sys.path.insert(0,str(ROOT/'scripts'))
from benchmark_quack import quantile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BACKENDS=('local','baseline','tidbfs')
LABELS={'local':'Quack + local file','baseline':'Quack + Go tidbfs','tidbfs':'Quack + C++ tidbfs'}
COLORS={'local':'#2872ad','baseline':'#8a939f','tidbfs':'#dd6c27'}
TITLES={'read_hot':'Warm 4,096-row aggregate','write1':'One-row durable transactions','write128':'128-row durable transactions','mixed90':'90% warm reads / 10% writes','read_stream':'Full scans, 64 MB DuckDB buffer pool'}
selected=[];excluded=[];records=[]
for stage in ('matrix','stream'):
 sources=[OUT/stage]+sorted(OUT.glob(stage+'-quality-*/'))
 groups=defaultdict(list);base=None
 for source in sources:
  data=json.loads((source/'results.json').read_text());assert 'finished_utc' in data
  if base is None:base=data
  assert data['binaries']==base['binaries']
  cases=defaultdict(list)
  for row in data['runs']:cases[(row['workload'],row['clients'],row['trial'])].append(row)
  for key,runs in sorted(cases.items()):
   assert {r['backend'] for r in runs}==set(BACKENDS) and len(runs)==3
   if not all(r['resource_eligible'] for r in runs):
    excluded.append({'source':source.name,'case':key,'reason':'active paging limit exceeded by at least one backend'})
   else:groups[key[:2]].append((source,runs))
 for key,values in groups.items():
  assert len(values)>=3,(stage,key,'fewer than three resource-qualified groups')
  use=values[:3]
  for source,runs in use:
   for run in runs:selected.append({'source':source.name,**run})
  for backend in BACKENDS:
   runs=[];latencies=[];read=[];write=[]
   for source,cases in use:
    item=next(row for row in cases if row['backend']==backend);runs.append(item)
    with (source/(item['name']+'-latencies.csv')).open() as f:
     for sample in csv.DictReader(f):
      value=float(sample['latency_ms']);latencies.append(value)
      (read if sample['kind']=='read' else write).append(value)
   qps=[r['throughput_qps'] for r in runs]
   records.append({'stage':stage,'workload':key[0],'clients':key[1],'backend':backend,'trials':3,'requests':len(latencies),
    'qps':statistics.median(qps),'qps_min':min(qps),'qps_max':max(qps),
    'p50_ms':quantile(latencies,.5),'p95_ms':quantile(latencies,.95),'p99_ms':quantile(latencies,.99),
    'read_p95_ms':quantile(read,.95),'write_p95_ms':quantile(write,.95),
     'read_qps':statistics.median(r['per_kind']['read']['qps'] for r in runs),
    'write_qps':statistics.median(r['per_kind']['write']['qps'] for r in runs),
    'rows_per_second':statistics.median(r['per_kind']['write']['qps'] for r in runs)*(128 if key[0]=='write128' else 1),
    'measured_write_percent':100*len(write)/len(latencies),
    'worker_cpu_cores':statistics.median(r['resources']['cpu_cores']['worker'] for r in runs),
    'client_cpu_cores':statistics.median(sum(r['resources']['cpu_cores'].get(k,0) for k in ('clients','driver')) for r in runs),
    'storage_cpu_cores':statistics.median(sum(value for k,value in r['resources']['cpu_cores'].items() if k not in ('worker','clients','driver')) for r in runs),
    'checkpoint_seconds':statistics.median(r['checkpoint_seconds'] for r in runs),
    'swapin_max_bytes':max(r['resources']['swapin_delta_bytes'] for r in runs),
    'swapout_max_bytes':max(r['resources']['swapout_delta_bytes'] for r in runs)})
result={'summary':records,'selected':selected,'excluded':excluded,
 'policy':'Whole three-backend groups; 64 MiB swap-out and 128 MiB swap-in limits; first three eligible groups chronologically, independent of performance.'}
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
with (OUT/'summary.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(records[0]),lineterminator='\n');writer.writeheader();writer.writerows(records)
for field,axislabel in [('qps','Completed SQL requests / second'),('p95_ms','Client p95 latency (ms)')]:
 fig,axes=plt.subplots(2,3,figsize=(14,8));axes=axes.flat
 for axis,workload in zip(axes,('read_stream','read_hot','write1','write128','mixed90')):
  for backend in BACKENDS:
   rows=sorted([r for r in records if r['workload']==workload and r['backend']==backend],key=lambda r:r['clients'])
   x=[r['clients'] for r in rows];y=[r[field] for r in rows]
   axis.plot(x,y,'o-',linewidth=2,color=COLORS[backend],label=LABELS[backend])
   if field=='qps':axis.fill_between(x,[r['qps_min'] for r in rows],[r['qps_max'] for r in rows],color=COLORS[backend],alpha=.12)
  axis.set_title(TITLES[workload]);axis.set_xlabel('Concurrent clients');axis.set_ylabel(axislabel);axis.grid(alpha=.2);axis.set_xticks(x)
  if workload in ('write1','write128','mixed90','read_stream'):axis.set_yscale('log')
 axes[-1].axis('off');handles,labels=axes[0].get_legend_handles_labels();axes[-1].legend(handles,labels,loc='center',frameon=False)
 fig.suptitle('DuckDB 2.0 / official Quack / TiDB-TiKV + RustFS on loopback',fontsize=14)
 fig.tight_layout();fig.savefig(OUT/(field+'.png'),dpi=160);fig.savefig(OUT/(field+'.svg'));plt.close(fig)
rows8=[r for r in records if r['clients']==8]
lines=['| Workload | Backend | SQL/s | p50 ms | p95 ms | p99 ms | Worker CPU cores |','|---|---|---:|---:|---:|---:|---:|']
for r in rows8:lines.append('| '+TITLES[r['workload']]+' | '+LABELS[r['backend']]+f" | {r['qps']:.2f} | {r['p50_ms']:.2f} | {r['p95_ms']:.2f} | {r['p99_ms']:.2f} | {r['worker_cpu_cores']:.2f} |")
(OUT/'table.md').write_text('\n'.join(lines)+'\n')
# Raw latency/metrics files contain no API credentials. Do not package service
# logs, transient environments, fault diagnostics, compiled plugins, or venvs.
with zipfile.ZipFile(OUT/'quack-cpp-client-results.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in [ROOT/'scripts/benchmark_quack.py',OUT/'summary.csv',OUT/'comparison.json',OUT/'qps.png',OUT/'p95_ms.png',OUT/'qps.svg',OUT/'p95_ms.svg',OUT/'analyze.py',OUT/'render_report.py',OUT/'run_final.py',OUT/'run_benchmarks.py',OUT/'requirements.lock',OUT/'fs-build-provenance.json',OUT/'final-pipeline.json',OUT/'final-source-rebuild.json',ROOT/'cpp-sdk-revision.txt']:
  archive.write(path,path.name)
 for directory in [OUT/'matrix',OUT/'stream']+sorted(OUT.glob('*-quality-*/')):
  for path in directory.iterdir():
   if path.name in ('results.json','bench.py') or path.name.endswith('-latencies.csv') or path.name.endswith('-metrics.json'):
    archive.write(path,str(path.relative_to(OUT)))
print('Selected',len(selected),'runs; excluded',len(excluded),'groups')
print('\n'.join(lines))
