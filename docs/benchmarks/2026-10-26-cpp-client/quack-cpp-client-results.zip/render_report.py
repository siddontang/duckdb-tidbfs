"""Render final C++/Go/local evidence after all timed workloads finish."""
import base64,html,json,shutil
from pathlib import Path
root=Path.cwd();out=root/'build/cpp-migration'
data=json.loads((out/'comparison.json').read_text());summary=data['summary']
fs_provenance=json.loads((out/'fs-build-provenance.json').read_text())
rebuild=json.loads((out/'final-source-rebuild.json').read_text())
meta=json.loads((out/'matrix/results.json').read_text());stream=json.loads((out/'stream/results.json').read_text())
labels={'local':'Quack + local file','baseline':'Quack + Go tidbfs','tidbfs':'Quack + C++ tidbfs'}
lookup={(r['workload'],r['clients'],r['backend']):r for r in summary}
a,b,c=[lookup[('read_stream',8,k)] for k in ('baseline','tidbfs','local')]
rows=''
for work in ('read_stream','read_hot','write1','write128','mixed90'):
 for backend in ('local','baseline','tidbfs'):
  r=lookup[(work,8,backend)]
  values=[work,labels[backend],f'{r["qps"]:.2f}',f'{r["p50_ms"]:.2f}',f'{r["p95_ms"]:.2f}',f'{r["p99_ms"]:.2f}',r['requests'],f'{r["worker_cpu_cores"]:.2f}']
  rows+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in values)+'</tr>'
images=''.join('<figure><img alt="'+name+'" src="data:image/png;base64,'+base64.b64encode((out/name).read_bytes()).decode()+'"></figure>' for name in ('qps.png','p95_ms.png'))
sizes={name:(root/path).stat().st_size/(1<<20) for name,path in {'cpp':'build/tidbfs.duckdb_extension','go':'build/cpp-migration/go-baseline/tidbfs.duckdb_extension'}.items()}
page=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Quack + pure C++ tidbfs</title><style>
body{{margin:0;background:#f5f7fa;color:#18222e;font:16px/1.55 system-ui,sans-serif}}main{{max-width:1240px;margin:auto;padding:36px 28px}}h1{{font-size:34px;line-height:1.15;margin:6px 0 16px}}h2{{margin-top:32px}}p{{max-width:1040px}}.eyebrow{{color:#526176;font-size:13px;text-transform:uppercase;letter-spacing:.08em}}.card{{padding:18px 22px;background:white;border:1px solid #dce2e9;border-radius:10px}}figure{{margin:24px 0}}img{{max-width:100%;height:auto}}table{{border-collapse:collapse;width:100%;font-size:13px;background:white}}th,td{{padding:9px 11px;border-bottom:1px solid #dce2e9;text-align:right}}th:first-child,td:first-child,td:nth-child(2){{text-align:left}}th{{background:#e9eef4}}code{{font-size:.9em;overflow-wrap:anywhere}}.scroll{{overflow-x:auto}}.muted{{color:#5c6775}}a{{color:#1468aa}}</style><main>
<div class="eyebrow">DuckDB 2.0 · official Quack · TiDB / TiKV · RustFS · 2026-10-26</div>
<h1>Pure C++ tidbfs over the existing HTTP APIs</h1>
<div class="card"><strong>8-client buffer-limited scans: {b['qps']/a['qps']:.2f}× throughput relative to Go tidbfs.</strong><br>Go {a['qps']:.2f} SQL/s → C++ {b['qps']:.2f} SQL/s; local file {c['qps']:.2f} SQL/s.<br>Client p95: Go {a['p95_ms']:.2f} ms; C++ {b['p95_ms']:.2f} ms.</div>
<p>The plugin uses the public drive9 C++ SDK. Existing file HTTP APIs handle analytical files; extent metadata and data-credential APIs support native files and immutable object I/O. Sessions, caller identity, record locks, open references, object keys and half-open ID reservations are shared with existing clients. There is no Go bridge, new endpoint or new table. A generic server repair keeps empty directories and renamed subtrees consistent across the existing API views, within the existing session-guarded transactions.</p>
<p>The SDK shares immutable cached blocks, coalesces simultaneous downloads and copies requested bytes into DuckDB's destination. Writes remain synchronous through object upload and metadata publication. The Go baseline already uses direct-buffer reads and the same 64 MiB cache budget. This compares complete implementations and does not isolate language-boundary overhead. Extension file size: {sizes['go']:.2f} MiB (Go) → {sizes['cpp']:.2f} MiB (C++), excluding system shared libraries.</p>
<h2>Throughput and latency</h2><p class="muted">Median throughput of three eligible trials; shading shows the trial range. Latencies pool successful requests. Whole three-backend groups are selected by predefined paging thresholds, independently of performance.</p>{images}
<h2>Eight concurrent clients</h2><div class="scroll"><table><thead><tr><th>Workload</th><th>Backend</th><th>SQL/s</th><th>p50 ms</th><th>p95 ms</th><th>p99 ms</th><th>Samples</th><th>Worker cores</th></tr></thead><tbody>{rows}</tbody></table></div>
<h2>Remaining bottlenecks</h2><p>Warm-read throughput differs by only 3.1% at eight clients. One-row writes are broadly unchanged; their p95 increases from 652.19 to 672.34 ms. The mixed workload drops from 192.70 to 150.76 SQL/s (−21.8%), with p95 rising from 119.39 to 146.63 ms. Remote write cases use less than 0.1 worker CPU core and stop scaling with more clients: synchronous object upload, metadata publication and queueing deserve profiling before adding CPU parallelism. These measurements do not isolate transport, object store, transaction or Quack scheduling costs.</p><p>Full scans remain at 44.1% of local throughput and peak at four clients. Bounded parallel fetch/prefetch and profiling cache/mapping/copy costs are follow-up candidates. Any commit batching must retain explicit durability and recovery semantics.</p><h2>Method and boundaries</h2><p>{html.escape(meta['cpu'])}, {meta['logical_cpus']} logical CPUs, {meta['memory_bytes']/(1<<30):.0f} GiB memory. Separate DuckDB CLI workers and independent Python DuckDB client instances/Quack sessions. The matrix uses 1/2/4/8/16 clients, a configured four worker threads (not a CPU affinity limit), a 1 GB buffer pool, 1,048,576 uncompressed 32-byte rows and 8-second admission windows. Streaming scans use 4,194,304 rows, a 64 MB buffer pool, 1/4/8 clients and 10-second windows. In-flight queries drain before the next case. Startup, attach, preparation and explicit checkpointing are excluded; checkpoint time is recorded separately. The 1 TB automatic checkpoint threshold isolates WAL commit latency.</p>
<p>TiDB/TiKV 8.5.3, one TiKV, and RustFS 1.0.3 run on this host with direct loopback connections. Backend order rotates. A whole triplet is excluded when any backend exceeds 64 MiB swap-out or 128 MiB swap-in. Excluded groups: {len(data['excluded'])}. The first three eligible triplets are selected chronologically. All raw samples and exclusion decisions are retained.</p>
<p>OS/object caches are not purged. Hot-query warm-up scans a,b,c plus three requests per client; early id-range misses remain possible. These are mostly cached and buffer-limited tests, not a physically cold storage or WAN benchmark. Small trial differences and low-sample p99 values cannot establish stable gains. File locks remain cooperative; production object-store/TiKV failover coverage remains incomplete.</p>
<h2>Compatibility and recovery</h2><p>31 analytical/HTTP regressions, standalone C++ protocol/TLS/deadline tests (including no TLS mutation replay), direct live C++ extent conformance, 22 native tests, eight Quack cases, and client/filesystem SIGKILL plus WAL recovery passed. The final artifact also passes Go → C++ → Go alternating database writes and cross-client Parquet creation/reads. The earlier draft reproduces an inode-ID conflict under this regression; the fixed SDK uses the existing half-open range contract.</p>
<p><a href="summary.csv">All configurations (CSV)</a> · <a href="quack-cpp-client-results.zip">Raw samples, metrics, provenance and scripts</a> · <a href="https://github.com/mem9-ai/drive9/pull/1056">C++ SDK PR</a> · <a href="https://github.com/siddontang/duckdb-tidbfs/pull/3">Plugin PR</a></p>
<p class="muted">C++ binary SHA-256: <code>{meta['binaries']['tidbfs']}</code><br>Plugin source: <code>{meta['feature_commit']}</code><br>Final SDK (byte-identical macOS rebuild): <code>{(root/'cpp-sdk-revision.txt').read_text().strip()}</code><br>Original validated/measured SDK: <code>{rebuild['original_measured_sdk_revision']}</code></p></main></html>'''
(out/'report.html').write_text(page)
public=root/'docs/benchmarks/2026-10-26-cpp-client';public.mkdir(parents=True,exist_ok=True)
for name in ('summary.csv','qps.png','p95_ms.png','quack-cpp-client-results.zip'):shutil.copy2(out/name,public/name)
provenance={'feature_commit':meta['feature_commit'],'cpp_sdk_commit':(root/'cpp-sdk-revision.txt').read_text().strip(),
 'main_commit':meta['main_commit'],'binaries':meta['binaries'],'benchmark_sha256':meta['benchmark_sha256'],
 'platform':meta['platform'],'cpu':meta['cpu'],'memory_bytes':meta['memory_bytes'],'method':meta['method'],
 'stream_method':stream['method'],'fs_commit':fs_provenance['fs_commit'], 'fs_binary_sha256':fs_provenance['binary_sha256'], 'fs_source_tree_clean':fs_provenance['source_tree_clean'], 'fs_embedded_vcs_metadata':False,
 'go_baseline_source':'c635e86df4ea2150d684cc4bcfb70f27df7adaf2','go_baseline_binary_sha256':meta['binaries']['baseline'],
 'go_baseline_note':'Previous optimized Go-backed implementation already using direct-buffer reads and a 64 MiB block cache, built with Go 1.26.0 before its source commit; historical embedded revision marks a dirty parent. Exact artifact retained.',
 'selected_runs':len(data['selected']),'excluded_groups':data['excluded'],'selection_policy':data['policy'],
 'extension_mib':sizes,'validation_artifact_sha256':json.loads((out/'final-pipeline.json').read_text())['binary_sha256'], 'validation_sdk_revision':json.loads((out/'final-pipeline.json').read_text())['sdk_revision']}
assert provenance['validation_artifact_sha256']==meta['binaries']['tidbfs']==stream['binaries']['tidbfs']
assert rebuild['sdk_revision']==provenance['cpp_sdk_commit']
assert rebuild['binary_sha256']==provenance['validation_artifact_sha256']
assert rebuild['original_measured_sdk_revision']==provenance['validation_sdk_revision']
provenance['final_source_rebuild']=rebuild
assert meta['binaries']['fs']==stream['binaries']['fs']==provenance['fs_binary_sha256']
(public/'results.json').write_text(json.dumps(provenance,indent=2)+'\n')
print('Report:',out/'report.html');print('Repository evidence:',public)
