"""Sequential validation and measurements; never overlap local timed runs."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,os,subprocess
ROOT=Path.cwd();OUT=ROOT/'build/cpp-migration';PY=ROOT/'build/quack-perf/venv/bin/python'
env=dict(os.environ,DUCKDB_AGENT_MODE='0',DUCKDB=str(ROOT/'build/duckdb-2.0.0/bin/duckdb'),
 TIDBFS_QUACK_EXTENSION=str(ROOT/'build/duckdb-2.0.0/extensions/v2.0.0/osx_arm64/quack.duckdb_extension'),
 TIDBFS_BENCH_CLUSTER_TAG='cpp-tidbfs-20261026',TIDBFS_REQUIRE_SESSION_GUARD='1',TIDBFS_INTEROP_EXTENSION=str(OUT/'go-baseline/tidbfs.duckdb_extension'),CMAKE=str(ROOT/'build/object-venv/bin/cmake'),CTEST=str(ROOT/'build/object-venv/bin/ctest'),OPENSSL_ROOT_DIR='/opt/homebrew/opt/openssl@3',PATH=str(PY.parent)+os.pathsep+os.environ['PATH'])
for key in ('TIDBFS_TEST_EXTENSION','TIDBFS_PROFILE_CAPTURE','TIDBFS_PROFILE_JSON','TIDBFS_PROFILE_CPU'):
 env.pop(key,None)
state={'stage':'starting','completed':[]}
def save(): (OUT/'pipeline.json').write_text(json.dumps(state,indent=2)+'\n')
def run(command,name):
 state['stage']=name;save();print('Starting',name,flush=True)
 with (OUT/(name+'.log')).open('w') as log:subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=log,check=True)
 state['completed'].append(name);save();print('Completed',name,flush=True)
common=[str(PY),'scripts/benchmark_quack.py','--duckdb',env['DUCKDB'],'--quack-extension',env['TIDBFS_QUACK_EXTENSION'],
 '--extension',str(ROOT/'build/tidbfs.duckdb_extension'),'--baseline-extension',str(OUT/'go-baseline/tidbfs.duckdb_extension'),
 '--tidb-server',str(ROOT/'build/tidb-tikv-wrapper.py'),'--fs-server',str(ROOT/'build/fs-cpp-optin-server'),'--rustfs-server',str(ROOT/'build/rustfs')]
try:
 state['sdk_revision']=(ROOT/'cpp-sdk-revision.txt').read_text().strip();state['production_sha256']=hashlib.sha256((ROOT/'build/tidbfs.duckdb_extension').read_bytes()).hexdigest();save()
 stages=[('stream',['--mode','stream','--rows','4194304','--workloads','read_stream','--clients','1,4,8','--duration','10','--trials','3']),
         ('matrix',['--rows','1048576','--clients','1,2,4,8,16','--duration','8','--trials','3'])]
 for name,extra in stages:
  run(common+['--out',str(OUT/name)]+extra,name)
  data=json.loads((OUT/name/'results.json').read_text());bad=defaultdict(set)
  for item in data['runs']:
   if not item['resource_eligible']:bad[item['workload']].add(item['clients'])
  for workload,counts in bad.items():
   retry=name+'-quality-'+workload
   rows='4194304' if name=='stream' else '1048576';duration='10' if name=='stream' else '8'
   run(common+['--out',str(OUT/retry),'--mode',name,'--rows',rows,'--workloads',workload,'--clients',','.join(map(str,sorted(counts))),
    '--duration',duration,'--trials','3'],retry)
 state['stage']='complete';save()
except BaseException as err:
 state['error']=type(err).__name__+': '+str(err);state['stage']='failed';save();raise
